from setuptools import setup, find_packages

setup(
    name='hebrew_errors',
    version='0.1.0',
    description='הדפסת שגיאות פייתון בעברית 🇮🇱',
    author='השם שלך',
    packages=find_packages(),
    python_requires='>=3.6',
)